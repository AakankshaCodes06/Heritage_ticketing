import { useState } from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Sites from '@/components/Sites';
import BookingForm from '@/components/BookingForm';
import About from '@/components/About';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import BackToTop from '@/components/BackToTop';
import BookingConfirmation from '@/components/BookingConfirmation';

export default function Home() {
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [bookingDetails, setBookingDetails] = useState<{
    site: string;
    date: string;
    tickets: number;
    name: string;
    email: string;
    phone: string;
    total: number;
    reference: string;
  } | null>(null);

  const handleBookingSubmit = (details: {
    site: string;
    date: string;
    tickets: number;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    total: number;
  }) => {
    // Generate a random booking reference
    const reference = `TI${Math.floor(Math.random() * 10000000).toString().padStart(8, '0')}`;
    
    setBookingDetails({
      site: details.site,
      date: details.date,
      tickets: details.tickets,
      name: `${details.firstName} ${details.lastName}`,
      email: details.email,
      phone: details.phone,
      total: details.total,
      reference
    });
    
    setShowConfirmation(true);
  };

  const closeConfirmation = () => {
    setShowConfirmation(false);
    setBookingDetails(null);
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      <Hero />
      <Sites />
      <BookingForm onSubmit={handleBookingSubmit} />
      <About />
      <Contact />
      <Footer />
      <BackToTop />
      {showConfirmation && bookingDetails && (
        <BookingConfirmation 
          details={bookingDetails}
          onClose={closeConfirmation}
        />
      )}
    </div>
  );
}
