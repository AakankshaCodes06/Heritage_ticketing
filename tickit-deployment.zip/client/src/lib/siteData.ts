export const siteData = [
  {
    id: 1,
    name: 'Taj Mahal',
    location: 'Agra, Uttar Pradesh',
    description: 'The iconic ivory-white marble mausoleum on the south bank of the Yamuna river, built by Emperor Shah Jahan.',
    image: 'https://images.unsplash.com/photo-1548013146-72479768bada?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    price: 1500
  },
  {
    id: 2,
    name: 'Khajuraho Temples',
    location: 'Chhatarpur, Madhya Pradesh',
    description: 'A group of Hindu and Jain temples famous for their nagara-style architectural symbolism and erotic sculptures.',
    image: 'https://pixabay.com/get/gd2ba008f7e03eb8a0bf6cf9d620745f8d1a23769fe811c3b8b88cefe0dfdb174a57ed9fd4621943bda3a87b49d569caa90c3e74a92c8c21d0f1feb7f4468b0e3_1280.jpg',
    price: 600
  },
  {
    id: 3,
    name: 'Hampi',
    location: 'Bellary, Karnataka',
    description: 'The ruins of Vijayanagar Empire featuring stunning temples, palaces, and monolithic sculptures in a surreal boulder-strewn landscape.',
    image: 'https://pixabay.com/get/g19933bf0a74c90bb052bee98cb592b5ada36aa84da93d62600bc453b45c0e89b87c9c6c91b9b8affa203202c903cb5d383cac01ed8424e60810f13e9967c4766_1280.jpg',
    price: 750
  },
  {
    id: 4,
    name: 'Red Fort',
    location: 'Delhi',
    description: 'A historic fort that served as the main residence of the Mughal Emperors, known for its massive red sandstone walls.',
    image: 'https://pixabay.com/get/ga483c2051fd4efbc337a4a89a70fba1be257c33533a1ab1f078c6c5ebea36e0217d570c48d1628b3c65a9bc847475b7f969dd0f05495fc9d66d1ba1c2c50572c_1280.jpg',
    price: 500
  },
  {
    id: 5,
    name: 'Konark Sun Temple',
    location: 'Puri, Odisha',
    description: 'A 13th-century Sun Temple known for its exquisite stone carvings and chariot wheel design dedicated to the sun god Surya.',
    image: 'https://pixabay.com/get/gdc4b6045d7f9b755d4a2ae9eba8517bd35b81450e5285d74d2d5bd6de5325b643d71af99b30f24909117783e7a8d2187b84148661e393c12150c15550d831ab6_1280.jpg',
    price: 400
  },
  {
    id: 6,
    name: 'Ajanta Caves',
    location: 'Aurangabad, Maharashtra',
    description: 'Buddhist cave monuments dating from the 2nd century BCE, featuring paintings and sculptures considered masterpieces of Buddhist art.',
    image: 'https://pixabay.com/get/gd8119d56ec3b1c6f60c20ffd16823db65019ce2bc1424f0d93f8b6c1cb2ac52ffc85676ebf136c988ac65330a4d1e0ec3a2fa501e94eaf3a63fa3af5ef9fe9bc_1280.jpg',
    price: 550
  }
];
