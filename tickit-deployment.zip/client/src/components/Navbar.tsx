import { useState, useEffect } from 'react';
import { Link } from 'wouter';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <header className={`sticky top-0 z-50 bg-white shadow-md transition-shadow ${isScrolled ? 'shadow-lg' : 'shadow-md'}`}>
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <a href="#home" className="flex items-center">
          <span className="text-2xl font-playfair font-bold text-secondary">Tick<span className="text-primary">It</span></span>
        </a>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <a href="#home" className="font-poppins font-medium hover:text-primary transition duration-300">Home</a>
          <a href="#sites" className="font-poppins font-medium hover:text-primary transition duration-300">Sites</a>
          <a href="#about" className="font-poppins font-medium hover:text-primary transition duration-300">About</a>
          <a href="#contact" className="font-poppins font-medium hover:text-primary transition duration-300">Contact</a>
          <a href="#booking" className="btn-primary">Book Now</a>
        </nav>
        
        {/* Mobile Menu Button */}
        <button 
          onClick={toggleMenu}
          className="md:hidden text-secondary focus:outline-none"
          aria-label="Toggle mobile menu"
        >
          <i className={`fas fa-${isMenuOpen ? 'times' : 'bars'} text-2xl`}></i>
        </button>
      </div>
      
      {/* Mobile Navigation */}
      <div className={`md:hidden bg-white border-t ${isMenuOpen ? 'block' : 'hidden'}`}>
        <div className="container mx-auto px-4 py-2 flex flex-col space-y-3">
          <a 
            href="#home" 
            className="font-poppins py-2 hover:text-primary transition duration-300"
            onClick={closeMenu}
          >
            Home
          </a>
          <a 
            href="#sites" 
            className="font-poppins py-2 hover:text-primary transition duration-300"
            onClick={closeMenu}
          >
            Sites
          </a>
          <a 
            href="#about" 
            className="font-poppins py-2 hover:text-primary transition duration-300"
            onClick={closeMenu}
          >
            About
          </a>
          <a 
            href="#contact" 
            className="font-poppins py-2 hover:text-primary transition duration-300"
            onClick={closeMenu}
          >
            Contact
          </a>
          <a 
            href="#booking" 
            className="btn-primary w-full text-center my-2"
            onClick={closeMenu}
          >
            Book Now
          </a>
        </div>
      </div>
    </header>
  );
}
