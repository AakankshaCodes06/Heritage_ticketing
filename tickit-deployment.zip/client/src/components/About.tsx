export default function About() {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="font-playfair font-bold text-3xl md:text-4xl text-secondary mb-4">About Tick It</h2>
            <p className="text-gray-600 mb-4">
              Founded in 2020, Tick It is dedicated to making India's cultural heritage accessible to everyone through a seamless digital booking experience.
            </p>
            <p className="text-gray-600 mb-6">
              Our mission is to preserve and promote India's rich heritage by connecting visitors with historical sites while reducing queues and improving the overall visitor experience.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="bg-lightBlue bg-opacity-30 p-2 rounded-full mr-4">
                  <i className="fas fa-ticket-alt text-primary"></i>
                </div>
                <div>
                  <h3 className="font-poppins font-semibold text-lg">Convenient Booking</h3>
                  <p className="text-gray-600 text-sm">Book tickets instantly for any heritage site from anywhere, anytime.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-lightBlue bg-opacity-30 p-2 rounded-full mr-4">
                  <i className="fas fa-users text-primary"></i>
                </div>
                <div>
                  <h3 className="font-poppins font-semibold text-lg">Skip the Queue</h3>
                  <p className="text-gray-600 text-sm">Avoid long lines with our digital tickets and dedicated entry lanes.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-lightBlue bg-opacity-30 p-2 rounded-full mr-4">
                  <i className="fas fa-landmark text-primary"></i>
                </div>
                <div>
                  <h3 className="font-poppins font-semibold text-lg">Support Preservation</h3>
                  <p className="text-gray-600 text-sm">A portion of each booking contributes to heritage preservation initiatives.</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1532375810709-75b1da00537c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
              alt="Heritage tourism" 
              className="rounded-xl shadow-lg w-full"
            />
            
            <div className="absolute -bottom-8 -left-8 bg-white p-4 rounded-xl shadow-lg hidden md:block">
              <div className="flex items-center">
                <div className="bg-success bg-opacity-10 p-2 rounded-full mr-3">
                  <i className="fas fa-check text-success"></i>
                </div>
                <div>
                  <p className="font-semibold">500,000+</p>
                  <p className="text-gray-600 text-xs">Tickets Booked</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Testimonials */}
        <div className="mt-20">
          <h3 className="font-playfair font-bold text-2xl md:text-3xl text-secondary mb-10 text-center">What Our Users Say</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Testimonial 
              text="Booking through Tick It made our family trip to Taj Mahal so convenient. No waiting in long queues, just scanned the QR code and we were in!"
              name="Rahul Singh"
              location="Delhi"
              initials="RS"
              rating={5}
            />
            
            <Testimonial 
              text="As a history enthusiast, I visit heritage sites frequently. Tick It has simplified the booking process, and their mobile tickets are so easy to use."
              name="Anjali Patel"
              location="Mumbai"
              initials="AP"
              rating={4.5}
            />
            
            <Testimonial 
              text="I used Tick It during my visit to India and it made exploring heritage sites so much easier. The information provided before booking was very helpful."
              name="John Smith"
              location="London"
              initials="JS"
              rating={5}
            />
          </div>
        </div>
      </div>
    </section>
  );
}

interface TestimonialProps {
  text: string;
  name: string;
  location: string;
  initials: string;
  rating: number;
}

function Testimonial({ text, name, location, initials, rating }: TestimonialProps) {
  return (
    <div className="bg-neutral p-6 rounded-xl shadow-sm">
      <div className="flex items-center mb-4">
        <div className="text-accent">
          {[...Array(Math.floor(rating))].map((_, i) => (
            <i key={i} className="fas fa-star"></i>
          ))}
          {rating % 1 !== 0 && <i className="fas fa-star-half-alt"></i>}
        </div>
      </div>
      <p className="text-gray-600 mb-4">{text}</p>
      <div className="flex items-center">
        <div className="w-10 h-10 bg-gray-300 rounded-full mr-3 flex items-center justify-center">
          <span className="text-gray-600 font-semibold">{initials}</span>
        </div>
        <div>
          <p className="font-semibold">{name}</p>
          <p className="text-gray-500 text-sm">{location}</p>
        </div>
      </div>
    </div>
  );
}
