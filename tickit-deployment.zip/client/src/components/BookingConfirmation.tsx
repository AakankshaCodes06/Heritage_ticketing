interface BookingConfirmationProps {
  details: {
    site: string;
    date: string;
    tickets: number;
    name: string;
    email: string;
    phone: string;
    total: number;
    reference: string;
  };
  onClose: () => void;
}

export default function BookingConfirmation({ details, onClose }: BookingConfirmationProps) {
  return (
    <div className="fixed inset-0 flex items-center justify-center z-50">
      <div className="absolute inset-0 bg-black bg-opacity-60" onClick={onClose}></div>
      <div className="bg-white rounded-xl p-8 max-w-md w-full relative z-10">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-success bg-opacity-20 rounded-full mb-4">
            <i className="fas fa-check-circle text-3xl text-success"></i>
          </div>
          <h3 className="font-playfair font-bold text-2xl text-secondary mb-2">Booking Successful!</h3>
          <p className="text-gray-600 mb-6">Your booking has been confirmed. A confirmation email has been sent to your registered email address.</p>
          <div className="bg-gray-50 p-4 rounded-lg text-left mb-6">
            <div className="flex justify-between border-b border-gray-200 py-2">
              <span className="text-gray-600">Booking Reference:</span>
              <span className="font-medium">{details.reference}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-gray-600">Total Amount Paid:</span>
              <span className="font-medium text-secondary">₹{details.total.toLocaleString()}</span>
            </div>
          </div>
          <button type="button" onClick={onClose} className="btn-primary w-full">Close</button>
        </div>
      </div>
    </div>
  );
}
