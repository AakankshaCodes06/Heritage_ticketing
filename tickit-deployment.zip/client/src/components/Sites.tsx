import { useState } from 'react';
import { siteData } from '@/lib/siteData';

export default function Sites() {
  return (
    <section id="sites" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-playfair font-bold text-3xl md:text-4xl text-secondary mb-4">Explore Heritage Sites</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">Discover India's most magnificent architectural wonders and book your tickets effortlessly</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {siteData.map((site) => (
            <SiteCard key={site.id} site={site} />
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <a href="#booking" className="btn-primary text-lg">Book Your Visit</a>
        </div>
      </div>
    </section>
  );
}

interface SiteProps {
  site: {
    id: number;
    name: string;
    location: string;
    description: string;
    image: string;
    price: number;
  };
}

function SiteCard({ site }: SiteProps) {
  return (
    <div className="site-card card-hover bg-white rounded-xl overflow-hidden shadow-md border border-gray-100">
      <img src={site.image} alt={site.name} className="w-full" />
      <div className="p-6">
        <h3 className="font-poppins font-semibold text-xl mb-2">{site.name}</h3>
        <div className="flex items-center mb-4 text-gray-600">
          <i className="fas fa-map-marker-alt mr-2 text-primary"></i>
          <span>{site.location}</span>
        </div>
        <p className="text-sm text-gray-600 mb-4">{site.description}</p>
        <div className="flex justify-between items-center">
          <span className="font-bold text-secondary">₹{site.price.toLocaleString()} <span className="text-sm font-normal">per person</span></span>
          <a href="#booking" className="btn-primary text-sm" data-site={site.name}>Book Ticket</a>
        </div>
      </div>
    </div>
  );
}
