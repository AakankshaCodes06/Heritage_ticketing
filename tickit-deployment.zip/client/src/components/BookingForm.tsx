import { useState, useEffect } from 'react';
import { siteData } from '@/lib/siteData';

interface BookingFormProps {
  onSubmit: (details: {
    site: string;
    date: string;
    tickets: number;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    total: number;
  }) => void;
}

export default function BookingForm({ onSubmit }: BookingFormProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [site, setSite] = useState('');
  const [visitDate, setVisitDate] = useState('');
  const [tickets, setTickets] = useState(1);
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [sitePrice, setSitePrice] = useState(0);
  const serviceFee = 100;

  useEffect(() => {
    // Check if URL has a site query parameter
    const hash = window.location.hash;
    const siteParam = new URLSearchParams(window.location.search).get('site');
    
    if (hash === '#booking' && siteParam) {
      setSite(siteParam);
      updateSitePrice(siteParam);
    }

    // Set minimum date to today
    const today = new Date();
    const formattedDate = today.toISOString().split('T')[0];
    document.getElementById('visit-date')?.setAttribute('min', formattedDate);
  }, []);

  const updateSitePrice = (siteName: string) => {
    const selectedSite = siteData.find(s => s.name === siteName);
    setSitePrice(selectedSite ? selectedSite.price : 0);
  };

  useEffect(() => {
    updateSitePrice(site);
  }, [site]);

  const validateStep = (step: number) => {
    const errors: Record<string, string> = {};

    if (step === 1) {
      if (!site) errors.site = 'Please select a heritage site';
      if (!visitDate) errors.visitDate = 'Please select a visit date';
      if (tickets < 1) errors.tickets = 'Please select at least 1 ticket';
    } else if (step === 2) {
      if (!firstName.trim()) errors.firstName = 'Please enter your first name';
      if (!lastName.trim()) errors.lastName = 'Please enter your last name';
      if (!email.trim()) errors.email = 'Please enter your email address';
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        errors.email = 'Please enter a valid email address';
      }
      if (!phone.trim()) errors.phone = 'Please enter your phone number';
      else if (!/^[0-9+\s()-]{10,15}$/.test(phone)) {
        errors.phone = 'Please enter a valid phone number';
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    setCurrentStep(currentStep - 1);
  };

  const decreaseTickets = () => {
    if (tickets > 1) {
      setTickets(tickets - 1);
    }
  };

  const increaseTickets = () => {
    if (tickets < 10) {
      setTickets(tickets + 1);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!agreedToTerms) {
      setValidationErrors({
        ...validationErrors,
        terms: 'Please agree to the terms and conditions'
      });
      return;
    }

    if (validateStep(3)) {
      onSubmit({
        site,
        date: visitDate,
        tickets,
        firstName,
        lastName,
        email,
        phone,
        total: (sitePrice * tickets) + serviceFee
      });
    }
  };

  return (
    <section id="booking" className="py-16 bg-lightBlue bg-opacity-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-playfair font-bold text-3xl md:text-4xl text-secondary mb-4">Book Your Tickets</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">Fast and secure booking for your next heritage adventure</p>
        </div>
        
        <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-8">
            <form id="booking-form" className="space-y-6" onSubmit={handleSubmit}>
              {/* Step 1: Select Site */}
              {currentStep === 1 && (
                <div className="booking-step">
                  <div className="mb-4">
                    <label htmlFor="site" className="block text-sm font-medium text-gray-700 mb-2">Select Heritage Site</label>
                    <select 
                      id="site" 
                      name="site" 
                      value={site}
                      onChange={(e) => setSite(e.target.value)}
                      className={`w-full p-3 border ${validationErrors.site ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-lightBlue focus:border-lightBlue`}
                    >
                      <option value="">Select a site</option>
                      {siteData.map(s => (
                        <option key={s.id} value={s.name}>{s.name}, {s.location.split(',')[0]}</option>
                      ))}
                    </select>
                    {validationErrors.site && <p className="text-error text-sm mt-1">{validationErrors.site}</p>}
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="visit-date" className="block text-sm font-medium text-gray-700 mb-2">Visit Date</label>
                      <input 
                        type="date" 
                        id="visit-date" 
                        name="visit-date"
                        value={visitDate}
                        onChange={(e) => setVisitDate(e.target.value)}
                        className={`w-full p-3 border ${validationErrors.visitDate ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-lightBlue focus:border-lightBlue`}
                      />
                      {validationErrors.visitDate && <p className="text-error text-sm mt-1">{validationErrors.visitDate}</p>}
                    </div>
                    <div>
                      <label htmlFor="tickets" className="block text-sm font-medium text-gray-700 mb-2">Number of Tickets</label>
                      <div className="flex items-center">
                        <button 
                          type="button" 
                          onClick={decreaseTickets}
                          className="bg-gray-200 text-gray-700 px-3 py-2 rounded-l-lg"
                        >
                          <i className="fas fa-minus"></i>
                        </button>
                        <input 
                          type="number" 
                          id="tickets" 
                          name="tickets"
                          value={tickets}
                          onChange={(e) => setTickets(parseInt(e.target.value) || 1)} 
                          min="1" 
                          max="10"
                          className="w-full p-3 border-y border-x-0 border-gray-300 text-center focus:ring-0 focus:border-gray-300"
                        />
                        <button 
                          type="button" 
                          onClick={increaseTickets}
                          className="bg-gray-200 text-gray-700 px-3 py-2 rounded-r-lg"
                        >
                          <i className="fas fa-plus"></i>
                        </button>
                      </div>
                      {validationErrors.tickets && <p className="text-error text-sm mt-1">{validationErrors.tickets}</p>}
                    </div>
                  </div>
                  
                  <div className="mt-6 flex justify-end">
                    <button type="button" onClick={nextStep} className="btn-primary">
                      Continue <i className="fas fa-arrow-right ml-2"></i>
                    </button>
                  </div>
                </div>
              )}
              
              {/* Step 2: Personal Information */}
              {currentStep === 2 && (
                <div className="booking-step">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="first-name" className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                      <input 
                        type="text" 
                        id="first-name" 
                        name="first-name"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        className={`w-full p-3 border ${validationErrors.firstName ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-lightBlue focus:border-lightBlue`}
                      />
                      {validationErrors.firstName && <p className="text-error text-sm mt-1">{validationErrors.firstName}</p>}
                    </div>
                    <div>
                      <label htmlFor="last-name" className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                      <input 
                        type="text" 
                        id="last-name" 
                        name="last-name"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        className={`w-full p-3 border ${validationErrors.lastName ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-lightBlue focus:border-lightBlue`}
                      />
                      {validationErrors.lastName && <p className="text-error text-sm mt-1">{validationErrors.lastName}</p>}
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                    <input 
                      type="email" 
                      id="email" 
                      name="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className={`w-full p-3 border ${validationErrors.email ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-lightBlue focus:border-lightBlue`}
                    />
                    {validationErrors.email && <p className="text-error text-sm mt-1">{validationErrors.email}</p>}
                  </div>
                  
                  <div className="mt-4">
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                    <input 
                      type="tel" 
                      id="phone" 
                      name="phone"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className={`w-full p-3 border ${validationErrors.phone ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-lightBlue focus:border-lightBlue`}
                    />
                    {validationErrors.phone && <p className="text-error text-sm mt-1">{validationErrors.phone}</p>}
                  </div>
                  
                  <div className="mt-6 flex justify-between">
                    <button 
                      type="button" 
                      onClick={prevStep}
                      className="bg-gray-200 text-gray-700 font-poppins font-medium py-2 px-6 rounded-lg hover:bg-gray-300 transition duration-300"
                    >
                      <i className="fas fa-arrow-left mr-2"></i> Back
                    </button>
                    <button type="button" onClick={nextStep} className="btn-primary">
                      Review Booking <i className="fas fa-arrow-right ml-2"></i>
                    </button>
                  </div>
                </div>
              )}
              
              {/* Step 3: Review and Confirm */}
              {currentStep === 3 && (
                <div className="booking-step">
                  <h3 className="font-poppins font-semibold text-xl mb-4">Review Your Booking</h3>
                  
                  <div className="bg-gray-50 p-4 rounded-lg mb-6">
                    <div className="flex justify-between border-b border-gray-200 py-2">
                      <span className="text-gray-600">Heritage Site:</span>
                      <span className="font-medium">{site}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-200 py-2">
                      <span className="text-gray-600">Visit Date:</span>
                      <span className="font-medium">{visitDate}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-200 py-2">
                      <span className="text-gray-600">Number of Tickets:</span>
                      <span className="font-medium">{tickets}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-200 py-2">
                      <span className="text-gray-600">Visitor Name:</span>
                      <span className="font-medium">{`${firstName} ${lastName}`}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-200 py-2">
                      <span className="text-gray-600">Email:</span>
                      <span className="font-medium">{email}</span>
                    </div>
                    <div className="flex justify-between py-2">
                      <span className="text-gray-600">Phone:</span>
                      <span className="font-medium">{phone}</span>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg mb-6">
                    <div className="flex justify-between border-b border-gray-200 py-2">
                      <span className="text-gray-600">Ticket Price:</span>
                      <span className="font-medium">₹{sitePrice.toLocaleString()} x {tickets}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-200 py-2">
                      <span className="text-gray-600">Service Fee:</span>
                      <span className="font-medium">₹{serviceFee}</span>
                    </div>
                    <div className="flex justify-between py-2">
                      <span className="text-gray-600 font-bold">Total Amount:</span>
                      <span className="font-bold text-secondary">₹{((sitePrice * tickets) + serviceFee).toLocaleString()}</span>
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <label className="flex items-start">
                      <input 
                        type="checkbox" 
                        checked={agreedToTerms}
                        onChange={(e) => setAgreedToTerms(e.target.checked)}
                        className={`mt-1 mr-2 ${validationErrors.terms ? 'border-error' : ''}`}
                      />
                      <span className="text-sm text-gray-600">I agree to the <a href="#" className="text-primary">terms and conditions</a> and confirm that the information provided is correct.</span>
                    </label>
                    {validationErrors.terms && <p className="text-error text-sm mt-1">{validationErrors.terms}</p>}
                  </div>
                  
                  <div className="mt-6 flex justify-between">
                    <button 
                      type="button" 
                      onClick={prevStep}
                      className="bg-gray-200 text-gray-700 font-poppins font-medium py-2 px-6 rounded-lg hover:bg-gray-300 transition duration-300"
                    >
                      <i className="fas fa-arrow-left mr-2"></i> Back
                    </button>
                    <button type="submit" className="btn-primary">
                      Confirm & Pay <i className="fas fa-lock ml-2"></i>
                    </button>
                  </div>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
