import { useState } from 'react';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim() && email.includes('@')) {
      setSubscribed(true);
      setEmail('');
      
      // Reset subscription status after 3 seconds
      setTimeout(() => {
        setSubscribed(false);
      }, 3000);
    }
  };

  return (
    <footer className="bg-secondary bg-opacity-90 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <a href="#home" className="flex items-center mb-4">
              <span className="text-2xl font-playfair font-bold">Tick<span className="text-primary">It</span></span>
            </a>
            <p className="text-sm text-lightBlue mb-4">
              Making India's rich heritage accessible to everyone through seamless digital booking.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-lightBlue hover:text-primary transition duration-300">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="text-lightBlue hover:text-primary transition duration-300">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-lightBlue hover:text-primary transition duration-300">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-lightBlue hover:text-primary transition duration-300">
                <i className="fab fa-linkedin-in"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-poppins font-semibold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#home" className="text-lightBlue hover:text-primary transition duration-300">Home</a></li>
              <li><a href="#sites" className="text-lightBlue hover:text-primary transition duration-300">Heritage Sites</a></li>
              <li><a href="#booking" className="text-lightBlue hover:text-primary transition duration-300">Book Tickets</a></li>
              <li><a href="#about" className="text-lightBlue hover:text-primary transition duration-300">About Us</a></li>
              <li><a href="#contact" className="text-lightBlue hover:text-primary transition duration-300">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-poppins font-semibold text-lg mb-4">Resources</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-lightBlue hover:text-primary transition duration-300">Help Center</a></li>
              <li><a href="#" className="text-lightBlue hover:text-primary transition duration-300">FAQs</a></li>
              <li><a href="#" className="text-lightBlue hover:text-primary transition duration-300">Site Guidelines</a></li>
              <li><a href="#" className="text-lightBlue hover:text-primary transition duration-300">Travel Tips</a></li>
              <li><a href="#" className="text-lightBlue hover:text-primary transition duration-300">Blog</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-poppins font-semibold text-lg mb-4">Newsletter</h3>
            <p className="text-sm text-lightBlue mb-4">Subscribe to get updates on new sites and special offers</p>
            <form className="flex mb-4" onSubmit={handleSubmit}>
              <input 
                type="email" 
                placeholder="Your email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="p-2 text-sm bg-mediumBlue border border-lightBlue rounded-l-lg w-full focus:outline-none focus:ring-1 focus:ring-primary"
              />
              <button type="submit" className="bg-primary px-4 rounded-r-lg hover:bg-opacity-90 transition duration-300">
                <i className="fas fa-paper-plane"></i>
              </button>
            </form>
            {subscribed && (
              <p className="text-xs text-accent mb-2">✓ Successfully subscribed!</p>
            )}
            <p className="text-xs text-lightBlue">We respect your privacy. Unsubscribe at any time.</p>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-mediumBlue text-center text-sm text-lightBlue">
          <p>&copy; {new Date().getFullYear()} Tick It. All rights reserved.</p>
          <div className="mt-2 space-x-4">
            <a href="#" className="hover:text-primary transition duration-300">Privacy Policy</a>
            <a href="#" className="hover:text-primary transition duration-300">Terms of Service</a>
            <a href="#" className="hover:text-primary transition duration-300">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
