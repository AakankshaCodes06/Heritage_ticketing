export default function Hero() {
  return (
    <section id="home" className="hero-pattern text-white">
      <div className="container mx-auto px-4 py-20 md:py-32 flex flex-col items-center text-center">
        <h1 className="font-playfair font-bold text-4xl md:text-6xl mb-6 leading-tight">
          Explore India's Rich Heritage
        </h1>
        <p className="font-inter text-xl md:text-2xl mb-10 max-w-2xl">
          Discover ancient wonders and cultural treasures with seamless online booking
        </p>
        <a href="#booking" className="btn-primary text-lg px-8 py-3">Book Your Tickets Now</a>
        
        <div className="mt-20 grid grid-cols-3 gap-4 max-w-lg">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 text-center">
            <p className="text-2xl font-bold">50+</p>
            <p className="text-sm">Heritage Sites</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 text-center">
            <p className="text-2xl font-bold">100K+</p>
            <p className="text-sm">Happy Visitors</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 text-center">
            <p className="text-2xl font-bold">4.8<span className="text-sm">/5</span></p>
            <p className="text-sm">User Rating</p>
          </div>
        </div>
      </div>
    </section>
  );
}
