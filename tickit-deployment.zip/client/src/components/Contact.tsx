import { useState } from 'react';

export default function Contact() {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormState({
      ...formState,
      [name]: value
    });
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formState.name.trim()) {
      newErrors.name = 'Please enter your name';
    }
    
    if (!formState.email.trim()) {
      newErrors.email = 'Please enter your email address';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formState.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    if (!formState.subject.trim()) {
      newErrors.subject = 'Please enter a subject';
    }
    
    if (!formState.message.trim()) {
      newErrors.message = 'Please enter your message';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      // Form is valid, simulate a submission
      setFormSubmitted(true);
      
      // Reset form after 5 seconds
      setTimeout(() => {
        setFormSubmitted(false);
        setFormState({
          name: '',
          email: '',
          subject: '',
          message: ''
        });
      }, 5000);
    }
  };

  return (
    <section id="contact" className="py-16 bg-secondary text-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div>
            <h2 className="font-playfair font-bold text-3xl md:text-4xl mb-4">Get in Touch</h2>
            <p className="mb-8">Have questions about booking or need assistance? Fill out the form and our team will get back to you shortly.</p>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="mr-4 text-accent text-xl">
                  <i className="fas fa-map-marker-alt"></i>
                </div>
                <div>
                  <h3 className="font-poppins font-semibold text-lg">Our Office</h3>
                  <p className="text-lightBlue">123 Heritage Lane, South Extension</p>
                  <p className="text-lightBlue">New Delhi, 110049</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="mr-4 text-accent text-xl">
                  <i className="fas fa-envelope"></i>
                </div>
                <div>
                  <h3 className="font-poppins font-semibold text-lg">Email Us</h3>
                  <p className="text-lightBlue">support@tickit.in</p>
                  <p className="text-lightBlue">info@tickit.in</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="mr-4 text-accent text-xl">
                  <i className="fas fa-phone-alt"></i>
                </div>
                <div>
                  <h3 className="font-poppins font-semibold text-lg">Call Us</h3>
                  <p className="text-lightBlue">+91 11 2345 6789</p>
                  <p className="text-lightBlue">+91 98765 43210</p>
                </div>
              </div>
              
              <div className="pt-4">
                <h3 className="font-poppins font-semibold text-lg mb-3">Follow Us</h3>
                <div className="flex space-x-4">
                  <a href="#" className="bg-mediumBlue hover:bg-primary transition duration-300 w-10 h-10 rounded-full flex items-center justify-center">
                    <i className="fab fa-facebook-f"></i>
                  </a>
                  <a href="#" className="bg-mediumBlue hover:bg-primary transition duration-300 w-10 h-10 rounded-full flex items-center justify-center">
                    <i className="fab fa-twitter"></i>
                  </a>
                  <a href="#" className="bg-mediumBlue hover:bg-primary transition duration-300 w-10 h-10 rounded-full flex items-center justify-center">
                    <i className="fab fa-instagram"></i>
                  </a>
                  <a href="#" className="bg-mediumBlue hover:bg-primary transition duration-300 w-10 h-10 rounded-full flex items-center justify-center">
                    <i className="fab fa-linkedin-in"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            {formSubmitted ? (
              <div className="bg-white text-gray-800 rounded-xl p-8 shadow-lg text-center py-16">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-success bg-opacity-20 rounded-full mb-4">
                  <i className="fas fa-check-circle text-3xl text-success"></i>
                </div>
                <h3 className="font-playfair font-bold text-xl text-secondary mb-2">Message Sent!</h3>
                <p className="text-gray-600">Thanks for reaching out. We'll get back to you shortly.</p>
              </div>
            ) : (
              <form id="contact-form" className="bg-white text-gray-800 rounded-xl p-8 shadow-lg" onSubmit={handleSubmit}>
                <div className="mb-4">
                  <label htmlFor="contact-name" className="block text-sm font-medium text-gray-700 mb-2">Your Name</label>
                  <input 
                    type="text" 
                    id="contact-name" 
                    name="name"
                    value={formState.name}
                    onChange={handleChange}
                    className={`w-full p-3 border ${errors.name ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-lightBlue focus:border-lightBlue`}
                  />
                  {errors.name && <p className="text-error text-sm mt-1">{errors.name}</p>}
                </div>
                
                <div className="mb-4">
                  <label htmlFor="contact-email" className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                  <input 
                    type="email" 
                    id="contact-email" 
                    name="email"
                    value={formState.email}
                    onChange={handleChange}
                    className={`w-full p-3 border ${errors.email ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-lightBlue focus:border-lightBlue`}
                  />
                  {errors.email && <p className="text-error text-sm mt-1">{errors.email}</p>}
                </div>
                
                <div className="mb-4">
                  <label htmlFor="contact-subject" className="block text-sm font-medium text-gray-700 mb-2">Subject</label>
                  <input 
                    type="text" 
                    id="contact-subject" 
                    name="subject"
                    value={formState.subject}
                    onChange={handleChange}
                    className={`w-full p-3 border ${errors.subject ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-lightBlue focus:border-lightBlue`}
                  />
                  {errors.subject && <p className="text-error text-sm mt-1">{errors.subject}</p>}
                </div>
                
                <div className="mb-6">
                  <label htmlFor="contact-message" className="block text-sm font-medium text-gray-700 mb-2">Your Message</label>
                  <textarea 
                    id="contact-message" 
                    name="message"
                    value={formState.message}
                    onChange={handleChange}
                    rows={5}
                    className={`w-full p-3 border ${errors.message ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-lightBlue focus:border-lightBlue`}
                  ></textarea>
                  {errors.message && <p className="text-error text-sm mt-1">{errors.message}</p>}
                </div>
                
                <button type="submit" className="btn-primary w-full">Send Message</button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
